"""
ARL V13.1 XDF to Organized CSV Converter

Purpose
- Convert one LabRecorder master XDF into organized participant/modality CSVs.
- Expand SpyGameMarkers JSON into readable columns.
- Add experiment_time_s to every exported stream using SESSION_START as t=0.
- Generate a simplified event timeline and a 10 Hz aligned overview for QC.
- Use ARL session device_map.json files when available to map generic Shimmer names
  (for example Shimmer_6231) to P01 ECG, P02 GSR, etc.

Important
- The master XDF remains the authoritative synchronized LSL recording.
- Raw browser audio/video remain WebM files; MEDIA_SYNC anchors in SpyGameMarkers and
  participant media_sync.csv sidecars align those files to the master LSL clock.
"""
from __future__ import annotations

import json
import os
import re
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import numpy as np
    import pandas as pd
    import pyxdf
except Exception as exc:
    np = pd = pyxdf = None
    IMPORT_ERROR = exc
else:
    IMPORT_ERROR = None

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA_DIR = PROJECT_ROOT / "data" / "sessions"


def safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", (name or "unnamed_stream").strip())


def first(value: Any, default: Any = "") -> Any:
    if isinstance(value, list) and value:
        return value[0]
    return value if value is not None else default


def info_value(stream: Dict[str, Any], key: str, default: Any = "") -> Any:
    return first(stream.get("info", {}).get(key, []), default)


def get_channel_labels(stream: Dict[str, Any], channel_count: int) -> List[str]:
    labels: List[str] = []
    try:
        channels = stream.get("info", {}).get("desc", [{}])[0].get("channels", [{}])[0].get("channel", [])
        if isinstance(channels, dict):
            channels = [channels]
        for ch in channels:
            labels.append(str(first(ch.get("label", []), "")).strip() if isinstance(ch, dict) else "")
    except Exception:
        labels = []
    if len(labels) != channel_count or any(not x for x in labels):
        labels = [f"ch_{i+1:02d}" for i in range(channel_count)]
    seen: Dict[str, int] = {}
    out = []
    for label in labels:
        base = safe_name(label)
        seen[base] = seen.get(base, 0) + 1
        out.append(base if seen[base] == 1 else f"{base}_{seen[base]}")
    return out


def stream_to_dataframe(stream: Dict[str, Any], t0: Optional[float] = None) -> "pd.DataFrame":
    timestamps = np.asarray(stream.get("time_stamps", []), dtype=float)
    samples = stream.get("time_series", [])
    df = pd.DataFrame(samples)
    if df.shape[1] == 0:
        df = pd.DataFrame(index=range(len(timestamps)))
    labels = get_channel_labels(stream, df.shape[1])
    if len(labels) == df.shape[1]:
        df.columns = labels
    df.insert(0, "lsl_timestamp", timestamps)
    if t0 is not None:
        df.insert(1, "experiment_time_s", timestamps - float(t0))
    return df


def parse_json_text(value: Any) -> Optional[Dict[str, Any]]:
    if isinstance(value, dict):
        return value
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text.startswith("{"):
        return None
    try:
        out = json.loads(text)
        return out if isinstance(out, dict) else None
    except Exception:
        return None


def find_marker_stream(streams: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    for s in streams:
        name = str(info_value(s, "name", ""))
        typ = str(info_value(s, "type", ""))
        if name == "SpyGameMarkers" or typ.lower() == "markers":
            return s
    return None


def marker_records(stream: Dict[str, Any]) -> List[Dict[str, Any]]:
    out = []
    ts = list(stream.get("time_stamps", []))
    samples = stream.get("time_series", [])
    for i, sample in enumerate(samples):
        raw = sample[0] if isinstance(sample, (list, tuple, np.ndarray)) and len(sample) else sample
        obj = parse_json_text(raw)
        if obj is None:
            obj = {"marker": str(raw)}
        rec = dict(obj)
        rec["lsl_timestamp"] = float(ts[i]) if i < len(ts) else rec.get("lsl_time")
        # value is often itself a JSON string for media metadata/sync anchors.
        nested = parse_json_text(rec.get("value"))
        if nested:
            for k, v in nested.items():
                rec.setdefault(f"value_{k}", v)
        out.append(rec)
    return out


def find_session_and_t0(streams: List[Dict[str, Any]]) -> Tuple[str, Optional[float], List[Dict[str, Any]]]:
    ms = find_marker_stream(streams)
    records = marker_records(ms) if ms else []
    sid = next((str(r.get("session_id")) for r in records if r.get("session_id")), "UNKNOWN")
    starts = [float(r["lsl_timestamp"]) for r in records if r.get("marker") == "SESSION_START" and r.get("lsl_timestamp") is not None]
    if starts:
        t0 = starts[0]
    elif records:
        t0 = min(float(r["lsl_timestamp"]) for r in records if r.get("lsl_timestamp") is not None)
    else:
        all_ts = [float(s.get("time_stamps", [])[0]) for s in streams if len(s.get("time_stamps", []))]
        t0 = min(all_ts) if all_ts else None
    return sid, t0, records


def marker_dataframe(records: List[Dict[str, Any]], t0: Optional[float]) -> "pd.DataFrame":
    preferred = [
        "experiment_time_s", "lsl_timestamp", "server_time_local", "server_time_utc",
        "session_id", "game_number", "round_number", "phase", "active_speaker",
        "player_id", "marker", "value", "value_segment", "value_media_elapsed_sec",
        "value_browser_perf_ms", "value_browser_time_utc",
    ]
    rows = []
    for r in records:
        row = dict(r)
        ts = row.get("lsl_timestamp")
        row["experiment_time_s"] = (float(ts) - float(t0)) if ts is not None and t0 is not None else None
        rows.append(row)
    df = pd.DataFrame(rows)
    ordered = [c for c in preferred if c in df.columns] + [c for c in df.columns if c not in preferred and c != "lsl_time"]
    return df[ordered] if len(df) else pd.DataFrame(columns=preferred)


def event_timeline_dataframe(marker_df: "pd.DataFrame") -> "pd.DataFrame":
    if marker_df.empty:
        return pd.DataFrame(columns=["experiment_time_s", "clock", "game", "round", "participant", "phase", "event", "detail"])
    rows = []
    for _, r in marker_df.iterrows():
        t = r.get("experiment_time_s")
        if pd.isna(t):
            continue
        sec = max(0.0, float(t))
        mm = int(sec // 60); ss = sec - 60 * mm
        pid = r.get("player_id")
        participant = "" if pd.isna(pid) else f"P{int(pid):02d}"
        rows.append({
            "experiment_time_s": round(sec, 6),
            "clock": f"{mm:02d}:{ss:06.3f}",
            "game": r.get("game_number", ""),
            "round": r.get("round_number", ""),
            "participant": participant,
            "phase": r.get("phase", ""),
            "event": r.get("marker", ""),
            "detail": r.get("value", ""),
        })
    return pd.DataFrame(rows)


def load_device_map(session_id: str) -> Dict[str, Dict[str, str]]:
    """Load immutable session mapping first, then fall back to the persistent registry.

    Session-specific mapping always wins so later hardware reassignments cannot change
    interpretation of an older experiment.
    """
    mapping: Dict[str, Dict[str, str]] = {}
    if session_id and session_id != "UNKNOWN":
        session_root = DEFAULT_DATA_DIR / session_id
        # V13/V13.1 participant snapshots
        participants = session_root / "participants"
        if participants.exists():
            for pdir in sorted(participants.glob("P*")):
                fp = pdir / "device_map.json"
                if not fp.exists():
                    continue
                try:
                    obj = json.loads(fp.read_text(encoding="utf-8"))
                    devices = obj.get("devices", {}) if isinstance(obj, dict) else {}
                    if isinstance(devices, dict):
                        mapping[pdir.name] = {str(k): str(v) for k, v in devices.items() if str(v).strip()}
                except Exception:
                    pass
        # Explicit session-level snapshot (preferred in V13.1)
        snap = session_root / "device_map.json"
        if snap.exists():
            try:
                obj = json.loads(snap.read_text(encoding="utf-8"))
                dm = obj.get("device_map", obj) if isinstance(obj, dict) else {}
                if isinstance(dm, dict):
                    for pid, mods in dm.items():
                        if isinstance(mods, dict):
                            mapping[str(pid)] = {str(k): str(v) for k,v in mods.items() if str(v).strip()}
            except Exception:
                pass
    if mapping:
        return mapping
    # Persistent registry fallback: {hardware_id:{participant, modality, stream_name}}
    reg = PROJECT_ROOT / "config" / "device_registry.json"
    if reg.exists():
        try:
            obj=json.loads(reg.read_text(encoding="utf-8"))
            devices=obj.get("devices", obj) if isinstance(obj, dict) else {}
            for hw, rec in devices.items():
                if not isinstance(rec, dict): continue
                pid=str(rec.get("participant","")).strip(); mod=str(rec.get("modality","")).strip()
                ident=str(rec.get("stream_name") or hw).strip()
                if pid and mod and ident:
                    mapping.setdefault(pid,{})[mod]=ident
        except Exception:
            pass
    return mapping

def classify_stream(stream: Dict[str, Any], device_map: Dict[str, Dict[str, str]]) -> Tuple[Optional[str], Optional[str]]:
    name = str(info_value(stream, "name", ""))
    typ = str(info_value(stream, "type", ""))
    source = str(info_value(stream, "source_id", ""))
    hay = f"{name} {typ} {source}".lower()

    # Best case: self-describing ARL stream names.
    m = re.search(r"\bP0?([1-5])\b", hay, flags=re.I)
    participant = f"P{int(m.group(1)):02d}" if m else None
    modality = None
    for mod in ["EEG", "ECG", "EMG", "GSR", "AUDIO", "VIDEO", "EYE"]:
        if re.search(rf"\b{mod}\b", hay, flags=re.I):
            modality = mod.title() if mod in {"AUDIO", "VIDEO"} else mod
            break

    # Device map lets generic Consensys names such as Shimmer_6231 become P01 ECG.
    for pid, mods in device_map.items():
        for mod, ident in mods.items():
            token = str(ident).strip().lower()
            if token and (token in hay or hay in token):
                return pid, mod
            # Also compare terminal hardware IDs such as 6231 from Shimmer_6231.
            id_tokens = re.findall(r"[a-z0-9]{4,}", token)
            if any(t in hay for t in id_tokens):
                return pid, mod
    return participant, modality


def _clock_string(sec: float) -> str:
    if not np.isfinite(sec): return ""
    mm=int(sec//60); ss=sec-mm*60
    return f"{mm:02d}:{ss:06.3f}"

def write_aligned_overview(stream_frames: List[Tuple[str, Optional[str], Optional[str], "pd.DataFrame"]], marker_df: "pd.DataFrame", out_path: Path, hz: float = 10.0) -> None:
    numeric=[]; max_t=0.0
    for name,pid,mod,df in stream_frames:
        if "experiment_time_s" not in df.columns or df.empty: continue
        cols=[c for c in df.columns if c not in {"lsl_timestamp","experiment_time_s"} and pd.api.types.is_numeric_dtype(df[c])]
        if not cols: continue
        max_t=max(max_t,float(pd.to_numeric(df["experiment_time_s"],errors="coerce").max()))
        numeric.append((name,pid,mod,df,cols))
    if max_t<=0 or not numeric: return
    step=1.0/hz; grid=np.arange(0.0,max_t+step/2,step)
    overview=pd.DataFrame({"experiment_time_s":grid})
    overview["experiment_time_mmss"]=[_clock_string(x) for x in grid]
    # Context is forward-filled, but event_marker is impulse-like and never forward-filled.
    if not marker_df.empty and "experiment_time_s" in marker_df.columns:
        md=marker_df.copy(); md["experiment_time_s"]=pd.to_numeric(md["experiment_time_s"],errors="coerce"); md=md.dropna(subset=["experiment_time_s"]).sort_values("experiment_time_s")
        ctx=[c for c in ["game_number","round_number","phase","active_speaker"] if c in md.columns]
        if ctx:
            overview=pd.merge_asof(overview.sort_values("experiment_time_s"),md[["experiment_time_s"]+ctx],on="experiment_time_s",direction="backward")
        overview=overview.rename(columns={"game_number":"game","round_number":"round","phase":"current_phase"})
        overview["event_marker"]=""; overview["event_detail"]=""
        for _,r in md.iterrows():
            j=int(np.argmin(np.abs(grid-float(r["experiment_time_s"]))))
            # only place event if within half a grid interval
            if abs(grid[j]-float(r["experiment_time_s"])) <= step/2+1e-9:
                marker=str(r.get("marker","") or ""); detail=str(r.get("value","") or "")
                overview.at[j,"event_marker"] = (overview.at[j,"event_marker"]+" | "+marker).strip(" |")
                overview.at[j,"event_detail"] = (overview.at[j,"event_detail"]+" | "+detail).strip(" |")
    for name,pid,mod,df,cols in numeric:
        x=pd.to_numeric(df["experiment_time_s"],errors="coerce").to_numpy(float); order=np.argsort(x); x=x[order]; valid=np.isfinite(x); x=x[valid]
        if len(x)<2: continue
        prefix=f"{pid or 'UNMAPPED'}_{mod or safe_name(name)}"
        for c in cols:
            y=pd.to_numeric(df[c],errors="coerce").to_numpy(float)[order][valid]; good=np.isfinite(y)
            if good.sum()<2: continue
            overview[f"{prefix}_{safe_name(c)}"]=np.interp(grid,x[good],y[good],left=np.nan,right=np.nan)
    overview.to_csv(out_path,index=False)

def write_quality_summary(summary_rows: List[Dict[str, Any]], stream_frames, out_path: Path) -> None:
    frame_by_name={name:df for name,_,_,df in stream_frames}
    rows=[]
    durations=[float(r["duration_seconds"]) for r in summary_rows if r.get("duration_seconds") not in (None,"") and r.get("modality")!="Markers"]
    session_dur=max(durations) if durations else 0.0
    for r in summary_rows:
        if r.get("modality")=="Markers": continue
        df=frame_by_name.get(r["name"]); gaps=0; max_gap=np.nan; eff=np.nan; coverage=np.nan
        if df is not None and len(df)>=2:
            ts=pd.to_numeric(df["lsl_timestamp"],errors="coerce").dropna().to_numpy(float)
            if len(ts)>=2:
                d=np.diff(ts); med=float(np.median(d[d>0])) if np.any(d>0) else np.nan
                max_gap=float(np.max(d)); gaps=int(np.sum(d>max(0.1,med*3))) if np.isfinite(med) else 0
                dur=float(ts[-1]-ts[0]); eff=(len(ts)-1)/dur if dur>0 else np.nan
                coverage=100.0*dur/session_dur if session_dur>0 else np.nan
        status="PASS"
        if not r.get("participant") or not r.get("modality"): status="WARNING_UNMAPPED"
        if np.isfinite(coverage) and coverage<95: status="WARNING_PARTIAL"
        if gaps>0 and status=="PASS": status="WARNING_GAPS"
        rows.append({**r,"effective_srate_hz":eff,"coverage_percent":coverage,"gap_count":gaps,"largest_gap_s":max_gap,"qc_status":status})
    pd.DataFrame(rows).to_csv(out_path,index=False)

def write_audio_event_sheets(session_id: str, marker_df: "pd.DataFrame") -> List[str]:
    """Map game markers onto each participant media timeline using periodic MEDIA_SYNC anchors."""
    written=[]; session_root=DEFAULT_DATA_DIR/session_id
    if marker_df.empty or "lsl_timestamp" not in marker_df.columns: return written
    events=marker_df.copy(); events["lsl_timestamp"]=pd.to_numeric(events["lsl_timestamp"],errors="coerce"); events=events.dropna(subset=["lsl_timestamp"])
    # Do not duplicate media-sync bookkeeping into the human audio event sheet.
    if "marker" in events.columns: events=events[~events["marker"].astype(str).str.contains("_MEDIA_SYNC$",regex=True)]
    for i in range(1,6):
        pid=f"P{i:02d}"; media=session_root/"participants"/pid/"media"; sync=media/f"{pid}_{session_id}_media_sync.csv"
        if not sync.exists(): continue
        try: sd=pd.read_csv(sync)
        except Exception: continue
        if not {"lsl_timestamp","media_elapsed_sec"}.issubset(sd.columns): continue
        sd["lsl_timestamp"]=pd.to_numeric(sd["lsl_timestamp"],errors="coerce"); sd["media_elapsed_sec"]=pd.to_numeric(sd["media_elapsed_sec"],errors="coerce"); sd=sd.dropna(subset=["lsl_timestamp","media_elapsed_sec"]).sort_values("lsl_timestamp")
        if len(sd)<2: continue
        x=sd["lsl_timestamp"].to_numpy(float); y=sd["media_elapsed_sec"].to_numpy(float)
        ev=events[(events["lsl_timestamp"]>=x.min())&(events["lsl_timestamp"]<=x.max())].copy()
        if ev.empty: continue
        ev["audio_time_s"]=np.interp(ev["lsl_timestamp"].to_numpy(float),x,y)
        ev["audio_time_mmss"]=[_clock_string(v) for v in ev["audio_time_s"]]
        cols=[c for c in ["audio_time_s","audio_time_mmss","lsl_timestamp","experiment_time_s","server_time_utc","server_time_local","game_number","round_number","phase","active_speaker","player_id","marker","value"] if c in ev.columns]
        out=media/f"{pid}_{session_id}_audio_events.csv"; ev[cols].to_csv(out,index=False); written.append(str(out))
    return written

def convert_xdf(xdf_path: Path, output_dir: Path) -> Dict[str, Any]:
    if pyxdf is None or pd is None or np is None:
        raise RuntimeError("Missing packages. Install with: pip install pyxdf pandas numpy")
    if not xdf_path.exists() or xdf_path.suffix.lower() != ".xdf":
        raise ValueError("Please select a real .xdf file.")

    output_dir.mkdir(parents=True, exist_ok=True)
    streams, header = pyxdf.load_xdf(str(xdf_path))
    session_id, t0, marker_records_list = find_session_and_t0(streams)
    device_map = load_device_map(session_id)

    markers_dir = output_dir / "markers"; markers_dir.mkdir(exist_ok=True)
    participants_dir = output_dir / "participants"; participants_dir.mkdir(exist_ok=True)
    unmapped_dir = output_dir / "unmapped_streams"; unmapped_dir.mkdir(exist_ok=True)
    overview_dir = output_dir / "overview"; overview_dir.mkdir(exist_ok=True)

    mdf = marker_dataframe(marker_records_list, t0)
    mdf.to_csv(markers_dir / f"{session_id}_SpyGameMarkers.csv", index=False)
    timeline = event_timeline_dataframe(mdf)
    timeline.to_csv(markers_dir / f"{session_id}_Event_Timeline.csv", index=False)

    summary_rows = []
    stream_frames = []
    exported_files = []
    for idx, stream in enumerate(streams, start=1):
        info = stream.get("info", {})
        name = str(first(info.get("name", []), f"stream_{idx:02d}"))
        stream_type = str(first(info.get("type", []), ""))
        nominal_srate = str(first(info.get("nominal_srate", []), ""))
        channel_count = int(float(first(info.get("channel_count", []), 0) or 0))
        timestamps = stream.get("time_stamps", [])
        if name == "SpyGameMarkers" or stream_type.lower() == "markers":
            df = mdf
            csv_path = markers_dir / f"{session_id}_SpyGameMarkers.csv"
            pid = modality = None
        else:
            df = stream_to_dataframe(stream, t0)
            pid, modality = classify_stream(stream, device_map)
            if pid and modality:
                pdir = participants_dir / pid / "physiology"; pdir.mkdir(parents=True, exist_ok=True)
                filename = f"{pid}_{safe_name(modality)}.csv"
                csv_path = pdir / filename
            else:
                filename = f"{idx:02d}_{safe_name(name)}.csv"
                csv_path = unmapped_dir / filename
            df.to_csv(csv_path, index=False)
            stream_frames.append((name, pid, modality, df))
        exported_files.append(str(csv_path))
        duration = float(timestamps[-1] - timestamps[0]) if len(timestamps) >= 2 else None
        summary_rows.append({
            "index": idx, "name": name, "type": stream_type, "participant": pid or "",
            "modality": modality or ("Markers" if name == "SpyGameMarkers" else ""),
            "nominal_srate": nominal_srate,
            "channel_count": channel_count if channel_count else max(df.shape[1] - 2, 0),
            "samples": int(len(df)), "duration_seconds": duration,
            "csv_file": str(csv_path.relative_to(output_dir)),
        })

    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(output_dir / "stream_summary.csv", index=False)
    write_aligned_overview(stream_frames, mdf, overview_dir / f"{session_id}_Aligned_Overview_10Hz.csv", hz=10.0)
    write_quality_summary(summary_rows, stream_frames, overview_dir / f"{session_id}_Data_Quality_Summary.csv")
    audio_event_files = write_audio_event_sheets(session_id, mdf)

    report = {
        "input_xdf": str(xdf_path), "output_dir": str(output_dir), "session_id": session_id,
        "experiment_t0_lsl": t0, "stream_count": len(streams), "streams": summary_rows,
        "device_map_loaded": device_map, "audio_event_files": audio_event_files, "xdf_header": header,
        "master_policy": "Keep this XDF as the authoritative synchronized LSL master. Browser WebM media remain separate and align via Pxx_MEDIA_SYNC anchors.",
        "status": "PASS" if len(streams) else "WARN_NO_STREAMS",
    }
    (output_dir / "stream_report.json").write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    return report


class ConverterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ARL V13.1 Master XDF → Organized CSV Converter")
        self.geometry("820x570")
        self.minsize(740, 500)
        self.xdf_var = tk.StringVar(); self.out_var = tk.StringVar(); self.status_var = tk.StringVar(value="Ready. Select the master XDF file.")
        self._build_ui()
        if IMPORT_ERROR is not None:
            messagebox.showwarning("Missing Packages", f"Install required packages with:\n\npip install pyxdf pandas numpy\n\nDetails: {IMPORT_ERROR}")

    def _build_ui(self):
        ttk.Label(self, text="ARL V13.1 Master XDF → Organized Data", font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=14, pady=(14,4))
        ttk.Label(self, text="Creates readable markers, participant/modality CSVs, and a 10 Hz synchronized overview.").pack(anchor="w", padx=14, pady=(0,8))
        frame=ttk.Frame(self); frame.pack(fill="x", padx=12, pady=8)
        ttk.Label(frame,text="Input master XDF").grid(row=0,column=0,sticky="w")
        ttk.Entry(frame,textvariable=self.xdf_var).grid(row=1,column=0,sticky="ew",padx=(0,8)); ttk.Button(frame,text="Browse...",command=self.browse_xdf).grid(row=1,column=1)
        ttk.Label(frame,text="Output folder").grid(row=2,column=0,sticky="w",pady=(12,0))
        ttk.Entry(frame,textvariable=self.out_var).grid(row=3,column=0,sticky="ew",padx=(0,8)); ttk.Button(frame,text="Browse...",command=self.browse_output).grid(row=3,column=1)
        frame.columnconfigure(0,weight=1)
        bf=ttk.Frame(self); bf.pack(fill="x",padx=12,pady=4)
        ttk.Button(bf,text="Convert + Organize",command=self.run_conversion).pack(side="left")
        ttk.Button(bf,text="Open Output Folder",command=self.open_output).pack(side="left",padx=8)
        ttk.Label(self,textvariable=self.status_var).pack(anchor="w",padx=14,pady=(8,4))
        self.log=tk.Text(self,height=17,wrap="word"); self.log.pack(fill="both",expand=True,padx=12,pady=(0,12)); self.write_log("Ready.\n")

    def browse_xdf(self):
        path=filedialog.askopenfilename(title="Select master XDF",filetypes=[("XDF files","*.xdf"),("All files","*.*")])
        if path:
            self.xdf_var.set(path); self.out_var.set(str(Path(path).with_suffix(""))+"_organized"); self.write_log(f"Selected: {path}\n")
    def browse_output(self):
        path=filedialog.askdirectory(title="Select output folder")
        if path: self.out_var.set(path)
    def write_log(self,text): self.log.insert("end",text); self.log.see("end"); self.update_idletasks()
    def run_conversion(self):
        xdf=Path(self.xdf_var.get().strip().strip('"')); out=Path(self.out_var.get().strip().strip('"'))
        if not str(xdf): return messagebox.showerror("Missing XDF","Select an XDF file.")
        try:
            self.status_var.set("Converting..."); self.write_log("\nStarting organized conversion...\n")
            r=convert_xdf(xdf,out)
            self.write_log(f"Session: {r['session_id']}\nStreams: {r['stream_count']}\n")
            for s in r['streams']: self.write_log(f"✓ {s['name']} -> {s['csv_file']}\n")
            self.write_log("\nCreated readable marker CSV + event timeline + 10 Hz overview.\n")
            self.status_var.set("Conversion complete."); messagebox.showinfo("Complete",f"Organized data saved to:\n{out}")
        except Exception as exc:
            self.status_var.set("Conversion failed."); self.write_log("\nERROR:\n"+str(exc)+"\n"+traceback.format_exc()+"\n"); messagebox.showerror("Conversion Failed",str(exc))
    def open_output(self):
        text=self.out_var.get().strip().strip('"')
        if text and Path(text).exists(): os.startfile(str(Path(text))) if os.name=="nt" else None

if __name__ == "__main__":
    ConverterApp().mainloop()
