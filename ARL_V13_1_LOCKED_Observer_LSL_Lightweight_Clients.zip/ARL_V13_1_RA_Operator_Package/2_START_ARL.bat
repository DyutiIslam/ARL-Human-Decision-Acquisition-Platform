@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ARL V13.1 - Data Collection
if not exist "ARL_Runtime\SETUP_COMPLETE.txt" goto :not_setup

if not exist "ARL_System\.venv\Scripts\python.exe" goto :not_setup
if not exist "ARL_System\app\main.py" goto :missing_files

echo =============================================================
echo  ARL V13.1 - DATA COLLECTION
echo =============================================================
echo Starting the ARL server...
echo Keep this window OPEN for the entire session.
echo.
cd /d "%~dp0ARL_System"
start "" /b cmd /c "timeout /t 3 /nobreak >nul & start \"\" http://127.0.0.1:8000/"
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 0.0.0.0 --port 8000

echo.
echo ARL server has stopped.
pause
exit /b

:not_setup
echo =============================================================
echo  ARL CANNOT START - COMPUTER SETUP IS NOT COMPLETE
echo =============================================================
echo Close this window and run: 1_SETUP_THIS_COMPUTER.bat
pause
exit /b 1

:missing_files
echo =============================================================
echo  ARL CANNOT START - SOFTWARE FILES ARE MISSING
echo =============================================================
echo Re-extract the complete ARL package and try again.
pause
exit /b 1
