@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title ARL V13.1 - First-Time ARL Runtime Setup

set "PYVER=3.11.9"
set "PYEXE=%~dp0ARL_Runtime\Python311\python.exe"
set "VENV_PY=%~dp0ARL_System\.venv\Scripts\python.exe"
set "INSTALLER=%TEMP%\python-%PYVER%-amd64.exe"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"

echo =============================================================
echo  ARL V13.1 - FIRST-TIME ARL RUNTIME SETUP
echo =============================================================
echo.
echo This setup prepares ONLY the ARL Python runtime and ARL packages.
echo It does NOT install Consensys Pro, EMOTIV PRO, LabRecorder,
echo or hardware/vendor drivers.
echo.
echo Internet access is required the first time this setup is run.
echo Do not close this window while setup is running.
echo.

if not exist "ARL_System\app\main.py" goto :missing_files
if not exist "ARL_System\requirements.txt" goto :missing_files

echo [1/6] ARL software files found.

if exist "%PYEXE%" (
  echo [2/6] Managed ARL Python runtime already exists.
) else (
  echo [2/6] Python is not installed for ARL. Preparing managed runtime...
  if not exist "ARL_Runtime" mkdir "ARL_Runtime"
  echo       Downloading Python %PYVER% from python.org...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -UseBasicParsing -Uri '%PYURL%' -OutFile '%INSTALLER%' } catch { Write-Host $_.Exception.Message; exit 1 }"
  if errorlevel 1 goto :download_failed
  if not exist "%INSTALLER%" goto :download_failed

  echo       Installing Python inside this ARL package...
  "%INSTALLER%" /quiet InstallAllUsers=0 PrependPath=0 Include_launcher=0 Include_test=0 Include_doc=0 Include_tcltk=1 Include_pip=1 Include_dev=1 Include_exe=1 Include_lib=1 Include_tools=1 Shortcuts=0 TargetDir="%~dp0ARL_Runtime\Python311"
  if errorlevel 1 goto :python_install_failed
  if not exist "%PYEXE%" goto :python_install_failed
  del /q "%INSTALLER%" >nul 2>nul
)

"%PYEXE%" --version
if errorlevel 1 goto :python_install_failed

echo [3/6] Managed Python runtime verified.

if not exist "%VENV_PY%" (
  echo [4/6] Creating isolated ARL Python environment...
  "%PYEXE%" -m venv "%~dp0ARL_System\.venv"
  if errorlevel 1 goto :setup_failed
) else (
  echo [4/6] Existing isolated ARL environment found.
)

echo [5/6] Installing/verifying ARL Python packages...
"%VENV_PY%" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 goto :package_failed
"%VENV_PY%" -m pip install --disable-pip-version-check -r "%~dp0ARL_System\requirements.txt"
if errorlevel 1 goto :package_failed

echo [6/6] Running ARL dependency self-test...
"%VENV_PY%" -c "import fastapi,uvicorn,sqlmodel,pydantic,pylsl,pyxdf,pandas,numpy; import tkinter; print('ARL dependency self-test: PASS')"
if errorlevel 1 goto :selftest_failed

if not exist "Data" mkdir "Data"
>"ARL_Runtime\SETUP_COMPLETE.txt" echo ARL V13.1 setup completed successfully on %DATE% %TIME%

echo.
echo =============================================================
echo  ARL V13.1 SETUP COMPLETE
echo =============================================================
echo This computer is ready to run the ARL application.
echo.
echo For normal sessions, double-click:
echo   2_START_ARL.bat
echo.
echo You do NOT need to install or use Python or pip manually.
echo =============================================================
pause
exit /b 0

:download_failed
echo.
echo =============================================================
echo  SETUP STOPPED - PYTHON DOWNLOAD FAILED
echo =============================================================
echo The ARL setup could not download its managed Python runtime.
echo Confirm this computer has internet access and can reach python.org,
echo then run 1_SETUP_THIS_COMPUTER.bat again.
echo If it still fails, take a screenshot and contact the ARL lead.
pause
exit /b 1

:python_install_failed
echo.
echo =============================================================
echo  SETUP STOPPED - ARL PYTHON RUNTIME COULD NOT BE PREPARED
echo =============================================================
echo Do not install Python manually unless instructed by the ARL lead.
echo Take a screenshot of this window and contact the ARL lead.
pause
exit /b 1

:package_failed
echo.
echo =============================================================
echo  SETUP STOPPED - ARL PACKAGES COULD NOT BE INSTALLED
echo =============================================================
echo Confirm internet access, then run this setup again.
echo If it still fails, take a screenshot and contact the ARL lead.
pause
exit /b 1

:selftest_failed
echo.
echo =============================================================
echo  SETUP STOPPED - ARL SELF-TEST FAILED
echo =============================================================
echo The runtime was prepared, but one or more ARL components did not load.
echo Take a screenshot and contact the ARL lead. Do not continue to data collection.
pause
exit /b 1

:missing_files
echo.
echo =============================================================
echo  SETUP STOPPED - ARL SOFTWARE FILES ARE MISSING
echo =============================================================
echo Re-extract the complete ARL ZIP. Do not move files individually.
echo Take a screenshot if the problem continues.
pause
exit /b 1

:setup_failed
echo.
echo =============================================================
echo  ARL SETUP FAILED
echo =============================================================
echo Do not edit software files. Take a screenshot of this window and
 echo contact the ARL lead with the computer name and this error.
pause
exit /b 1
