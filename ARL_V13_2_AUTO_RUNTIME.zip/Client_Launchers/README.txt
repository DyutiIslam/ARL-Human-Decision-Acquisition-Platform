ARL V13.2 LIGHTWEIGHT CLIENT LAUNCHERS

These files are for participant and observer computers only.
They do NOT install Python and do NOT contain the ARL server code.

FIRST USE ON A CLIENT COMPUTER
1. Copy this Client_Launchers folder to the computer.
2. Run SET_ARL_HOST.bat once and enter the Moderator/Host computer IP address.
3. Use only the launcher assigned to that station.

P1: Launch_ARL_P1.bat
P2: Launch_ARL_P2.bat
P3: Launch_ARL_P3.bat
P4: Launch_ARL_P4.bat
P5: Launch_ARL_P5.bat
Observer: Launch_ARL_Observer.bat

The Moderator/Host computer must be running 2_START_ARL.bat and must be reachable on port 8000.
The Observer page is read-only. It displays participant connection status and LSL streams discovered by the ARL host. LabRecorder remains the recording application.
