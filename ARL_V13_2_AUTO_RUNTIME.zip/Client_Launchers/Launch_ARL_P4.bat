@echo off
setlocal
cd /d "%~dp0"
if not exist ARL_HOST.txt (
  echo ARL host is not configured.
  echo Run SET_ARL_HOST.bat first.
  pause
  exit /b 1
)
set /p HOST=<ARL_HOST.txt
start "" "http://%HOST%:8000/p4"
exit /b 0
