@echo off
setlocal
cd /d "%~dp0"
echo ========================================
echo ARL CLIENT HOST SETUP
echo ========================================
echo.
set /p HOST=Enter the Moderator/Host computer IP address (example 10.74.48.190): 
if "%HOST%"=="" (
  echo No address entered. Nothing changed.
  pause
  exit /b 1
)
>ARL_HOST.txt echo %HOST%
echo.
echo Saved ARL host: %HOST%
echo Participant and Observer launchers are ready.
pause
