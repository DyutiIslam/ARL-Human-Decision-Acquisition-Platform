from __future__ import annotations
import json,re
from pathlib import Path
from typing import Any,Dict
ROOT=Path(__file__).resolve().parents[1]
REGISTRY=ROOT/"config"/"device_registry.json"

def hardware_id(name:str, source_id:str="")->str:
    text=f"{name} {source_id}"
    m=re.search(r"Shimmer[_ -]?([A-Za-z0-9]{4})",text,re.I)
    if m:return m.group(1).upper()
    return (source_id or name).strip()

def load_registry()->Dict[str,Any]:
    if not REGISTRY.exists(): return {"version":"13.1","devices":{}}
    try:
        x=json.loads(REGISTRY.read_text(encoding="utf-8")); x.setdefault("devices",{}); return x
    except Exception:return {"version":"13.1","devices":{}}

def save_registry(obj:Dict[str,Any])->None:
    REGISTRY.parent.mkdir(parents=True,exist_ok=True); REGISTRY.write_text(json.dumps(obj,indent=2),encoding="utf-8")

def update_registry(assignments):
    reg=load_registry()
    for a in assignments:
        hw=str(a.get("hardware_id","")).strip().upper();
        if not hw: continue
        reg["devices"][hw]={"participant":str(a.get("participant","")).strip(),"modality":str(a.get("modality","")).strip().upper(),"stream_name":str(a.get("stream_name","")).strip()}
    save_registry(reg); return reg
