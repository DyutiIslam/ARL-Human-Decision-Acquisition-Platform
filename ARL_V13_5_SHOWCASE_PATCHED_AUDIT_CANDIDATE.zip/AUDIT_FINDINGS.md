# ARL V13.5 — Preliminary source audit and targeted patch

## Corrected
- All five participant launchers and the connection tester used a hard-coded `192.168.2.38`. They now load `Participant_Launchers/SERVER_CONFIG.bat` (default `192.168.2.40`).
- Corrected the stale internal `APP_VERSION` string (previously v13.2).

## Source review observations — not yet validated or corrected
- `static/participant.html` starts recording on a transition into `SESSION_START`, but media setup is initiated by a participant action. A participant who sets up media after `SESSION_START` may not start recording automatically. Test this explicitly.
- Media uploads are asynchronous on recorder stop; closing participant pages before uploads finish risks lost files. Check actual files before shutdown.
- Participant page `pagehide` fallback uses a 50 ms timer; timers may be suspended during navigation. Do not rely on this for saving data.
- UI confirmation of LabRecorder is not proof of valid XDF recording.
- `CORSMiddleware` allows all origins; suitable access control and HTTPS should be reviewed before use outside a trusted lab LAN.
- The showcase notes explicitly say this build has not been validated for research collection.

## Checks performed
- Python source syntax compilation.
- ZIP archive integrity.
- Launcher IP reference scan.

## Required on Windows before showcase
1. Clean install in a new folder; start one server only.
2. Confirm P1–P5 connect using launchers, camera preview, microphone levels and permission state.
3. Run a complete 5-participant game, and separately a full five-game session.
4. Verify per-participant video and audio outputs, nonempty file sizes, playback, upload completion and sync anchors.
5. Confirm vote/confidence/reasoning records, phase markers and LSL sample streams for all five participants.
6. Inspect XDF in LabRecorder and exported CSV rows; test reconnect/restart and emergency stop.
7. Compare timing and balanced speaking order across rounds.

This package is a **patched test candidate**, not a bug-free or research-validated release.
