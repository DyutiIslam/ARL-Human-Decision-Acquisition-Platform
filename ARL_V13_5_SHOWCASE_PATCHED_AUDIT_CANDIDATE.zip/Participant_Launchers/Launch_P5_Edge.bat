@echo off
setlocal
TITLE ARL Participant P5
call "%~dp0SERVER_CONFIG.bat"
if not defined SERVER_IP (echo [ERROR] SERVER_IP is missing in SERVER_CONFIG.bat & pause & exit /b 1)
set "ORIGIN=http://%SERVER_IP%:%PORT%"
set "URL=%ORIGIN%/p5"
set "PROFILE=%LOCALAPPDATA%\ARL_Research\EdgeProfiles\P5"

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" (
  echo [ERROR] Microsoft Edge was not found.
  echo Install Edge or edit this launcher to point to msedge.exe.
  pause
  exit /b 1
)

echo ================================================================
echo ARL Participant 5
echo Server: %ORIGIN%
echo ================================================================
echo.
echo IMPORTANT:
echo - Keep this Edge window separate from your normal Edge windows.
echo - The dedicated profile makes the secure-origin camera/mic flag reliable.
echo - If moderator IP changes, edit SERVER_CONFIG.bat once.
echo.
start "ARL P5" "%EDGE%" ^
  --user-data-dir="%PROFILE%" ^
  --new-window ^
  --no-first-run ^
  --no-default-browser-check ^
  --unsafely-treat-insecure-origin-as-secure="%ORIGIN%" ^
  "%URL%"
endlocal
