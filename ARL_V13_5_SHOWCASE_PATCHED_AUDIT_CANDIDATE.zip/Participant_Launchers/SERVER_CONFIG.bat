@echo off
rem Set this to the moderator laptop IPv4 address on the experiment LAN.
set "SERVER_IP=192.168.2.40"
set "PORT=8000"
