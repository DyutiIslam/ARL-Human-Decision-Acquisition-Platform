ARL V13.5 participant launchers

1. On every participant PC, edit SERVER_CONFIG.bat to match the moderator laptop IPv4 address (default 192.168.2.40).
2. Run Test_Server_Connection.bat. Confirm TcpTestSucceeded=True.
3. Close prior dedicated ARL Edge windows and run Launch_P1_Edge.bat through Launch_P5_Edge.bat on the corresponding stations.
4. Grant camera/microphone permissions and verify live media preview and audio level.
5. Use a stable LAN address or DHCP reservation. If the IP changes, update SERVER_CONFIG.bat on EVERY participant PC.

SECURITY: Edge insecure-origin override is intended for an isolated trusted laboratory LAN only; use HTTPS for deployments on untrusted networks.
