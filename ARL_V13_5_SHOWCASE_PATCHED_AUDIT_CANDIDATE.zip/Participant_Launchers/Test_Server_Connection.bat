@echo off
setlocal
call "%~dp0SERVER_CONFIG.bat"
echo Testing ARL moderator server %SERVER_IP%:%PORT%...
powershell -NoProfile -Command "Test-NetConnection %SERVER_IP% -Port %PORT%"
echo.
echo If TcpTestSucceeded is True, the network and firewall path are open.
pause
endlocal
