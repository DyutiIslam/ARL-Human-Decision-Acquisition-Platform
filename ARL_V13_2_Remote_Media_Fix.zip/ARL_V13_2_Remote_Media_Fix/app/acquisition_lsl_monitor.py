from __future__ import annotations

from dataclasses import asdict, dataclass
import re
from typing import Any, Dict, List, Optional

try:
    from pylsl import StreamInlet, local_clock, resolve_streams
except Exception:
    StreamInlet = None
    local_clock = None
    resolve_streams = None


# Canonical modality names used inside ARL.  The vendor stream name/type is always
# preserved separately; these aliases are only for readiness classification.
_MODALITY_PATTERNS = (
    ("EEG", ("eeg", "emotiv", "insight", "electroenceph")),
    ("ECG", ("ecg", "ekg", "electrocardio")),
    ("EMG", ("emg", "electromy")),
    ("GSR", ("gsr", "eda", "electrodermal", "skin conductance", "skinconductance")),
    ("EYE", ("eye", "gaze", "eyetracker", "eye tracker", "pupil")),
    ("MARKERS", ("marker", "markers", "event", "events", "trigger", "spygame")),
    ("AUDIO", ("audio", "microphone", "mic")),
    ("VIDEO", ("video", "camera", "webcam")),
)

PARTICIPANT_RE = re.compile(r"(?:^|[^a-z0-9])p(?:articipant)?[-_ ]?0*([1-5])(?:[^a-z0-9]|$)", re.I)


@dataclass
class AcquisitionStreamCheck:
    name: str
    type: str
    modality: str
    source_id: str
    uid: str
    hostname: str
    channel_count: int
    nominal_srate: float
    channel_format: str
    created_at_lsl: float
    channel_labels: List[str]
    participant_hint: Optional[int]
    sample_checked: bool
    sample_available: bool
    sample_timestamp_lsl: Optional[float]
    sample_length: Optional[int]
    validation_status: str
    warnings: List[str]

    def dict(self) -> Dict[str, Any]:
        return asdict(self)


def acquisition_lsl_available() -> bool:
    return StreamInlet is not None and resolve_streams is not None and local_clock is not None


def _child_text(node: Any, name: str) -> str:
    try:
        child = node.child(name)
        value = child.child_value()
        return value or ""
    except Exception:
        return ""


def _channel_labels(info: Any) -> List[str]:
    labels: List[str] = []
    try:
        ch = info.desc().child("channels").child("channel")
        for _ in range(int(info.channel_count())):
            label = _child_text(ch, "label") or _child_text(ch, "name")
            labels.append(label or "")
            ch = ch.next_sibling()
    except Exception:
        pass
    return labels


def classify_modality(name: str, stream_type: str, channel_labels: Optional[List[str]] = None) -> str:
    """Classify an LSL stream without changing or republishing it.

    The native vendor-provided name and type remain authoritative.  Classification
    is intentionally permissive so that ConsensysPRO/EmotivPRO naming can be learned
    from real hardware before stricter readiness rules are introduced.
    """
    labels = channel_labels or []
    haystack = " ".join([name or "", stream_type or "", *labels]).lower()
    for modality, aliases in _MODALITY_PATTERNS:
        if any(alias in haystack for alias in aliases):
            return modality
    return "OTHER"


def _participant_hint(name: str, stream_type: str, source_id: str) -> Optional[int]:
    text = " ".join((name or "", stream_type or "", source_id or ""))
    match = PARTICIPANT_RE.search(text)
    return int(match.group(1)) if match else None


def scan_acquisition_streams(timeout: float = 1.5, pull_sample: bool = True) -> Dict[str, Any]:
    """Discover all visible LSL streams for ARL acquisition preflight.

    This function is read-only with respect to the acquisition ecosystem: it does
    not start/stop EmotivPRO, ConsensysPRO, LabRecorder, or any hardware stream and
    does not republish vendor data.  It only discovers metadata and optionally opens
    a short-lived inlet to verify that a continuous stream is producing samples.
    """
    empty_summary = {
        "total_streams": 0,
        "sample_checked": 0,
        "sample_available": 0,
        "by_modality": {m: 0 for m in ("EEG", "ECG", "EMG", "GSR", "EYE", "MARKERS", "AUDIO", "VIDEO", "OTHER")},
    }

    if not acquisition_lsl_available():
        return {
            "available": False,
            "lsl_clock": None,
            "streams": [],
            "summary": empty_summary,
            "error": "pylsl/liblsl is not available. Install pylsl and make sure liblsl is accessible.",
        }

    try:
        infos = resolve_streams(wait_time=timeout)
    except Exception as exc:
        return {
            "available": True,
            "lsl_clock": float(local_clock()) if local_clock else None,
            "streams": [],
            "summary": empty_summary,
            "error": str(exc),
        }

    found: List[AcquisitionStreamCheck] = []
    for info in infos:
        warnings: List[str] = []
        labels = _channel_labels(info)

        try:
            name = info.name() or ""
            stream_type = info.type() or ""
            source_id = info.source_id() or ""
            uid = info.uid() or ""
            hostname = info.hostname() or ""
            channel_count = int(info.channel_count())
            nominal_srate = float(info.nominal_srate())
            channel_format = str(info.channel_format())
            created_at_lsl = float(info.created_at())
        except Exception as exc:
            warnings.append(f"Could not read complete stream metadata: {exc}")
            continue

        modality = classify_modality(name, stream_type, labels)
        participant_hint = _participant_hint(name, stream_type, source_id)

        if channel_count <= 0:
            warnings.append("Stream reports zero channels.")
        if modality not in {"MARKERS", "OTHER"} and nominal_srate <= 0:
            warnings.append("Continuous stream reports a non-positive nominal sampling rate.")

        sample_checked = bool(pull_sample and modality != "MARKERS")
        sample_available = False
        sample_ts: Optional[float] = None
        sample_len: Optional[int] = None

        if sample_checked:
            try:
                inlet = StreamInlet(info, max_buflen=2, recover=True)
                sample, ts = inlet.pull_sample(timeout=0.35)
                if sample is not None:
                    sample_available = True
                    sample_ts = float(ts)
                    sample_len = len(sample)
                    if sample_len != channel_count:
                        warnings.append(f"Sample length {sample_len} does not match channel count {channel_count}.")
            except Exception as exc:
                warnings.append(f"Sample pull failed: {exc}")

        if modality == "MARKERS":
            validation_status = "marker_stream_visible"
        elif sample_available and not warnings:
            validation_status = "stream_sample_available"
        elif sample_available:
            validation_status = "stream_sample_available_with_warnings"
        elif sample_checked:
            validation_status = "stream_visible_no_sample"
        else:
            validation_status = "stream_visible"

        found.append(AcquisitionStreamCheck(
            name=name,
            type=stream_type,
            modality=modality,
            source_id=source_id,
            uid=uid,
            hostname=hostname,
            channel_count=channel_count,
            nominal_srate=nominal_srate,
            channel_format=channel_format,
            created_at_lsl=created_at_lsl,
            channel_labels=labels,
            participant_hint=participant_hint,
            sample_checked=sample_checked,
            sample_available=sample_available,
            sample_timestamp_lsl=sample_ts,
            sample_length=sample_len,
            validation_status=validation_status,
            warnings=warnings,
        ))

    by_modality = {m: 0 for m in ("EEG", "ECG", "EMG", "GSR", "EYE", "MARKERS", "AUDIO", "VIDEO", "OTHER")}
    for stream in found:
        by_modality[stream.modality] = by_modality.get(stream.modality, 0) + 1

    return {
        "available": True,
        "lsl_clock": float(local_clock()),
        "streams": [s.dict() for s in found],
        "summary": {
            "total_streams": len(found),
            "sample_checked": sum(1 for s in found if s.sample_checked),
            "sample_available": sum(1 for s in found if s.sample_available),
            "by_modality": by_modality,
        },
        "error": None,
    }
