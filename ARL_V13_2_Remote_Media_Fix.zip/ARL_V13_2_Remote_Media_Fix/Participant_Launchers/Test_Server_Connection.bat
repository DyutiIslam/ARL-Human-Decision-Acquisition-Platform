@echo off
setlocal
set "SERVER_IP=192.168.2.38"
set "PORT=8000"
echo Testing ARL moderator server %SERVER_IP%:%PORT%...
powershell -NoProfile -Command "Test-NetConnection %SERVER_IP% -Port %PORT%"
echo.
echo If TcpTestSucceeded is True, the network and firewall path are open.
pause
endlocal
