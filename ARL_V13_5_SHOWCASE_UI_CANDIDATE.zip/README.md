# ARL V13.5 — Lab Ready / Public Source Release

## First-time setup
1. Extract this folder to a normal local location.
2. Double-click **1_SETUP_ARL.bat** once.
3. Setup automatically finds an installed Python 3.11, 3.12, or 3.13, creates an isolated `.venv`, installs the ARL dependencies there, and runs a launch-readiness test.
4. When setup reports **ARL SETUP COMPLETE - READY TO LAUNCH**, use **2_START_ARL.bat** for experiment sessions.
5. Use **3_CONVERT_XDF.bat** for XDF conversion.

ARL does **not** modify the computer's existing Python packages, Windows PATH, VS Code, or Anaconda environments. The installed Python is used only to create ARL's private `.venv`.

The first setup requires internet access to install Python packages into `.venv`. Normal launches do not reinstall packages.

If no supported Python is detected, setup stops with a clear message rather than installing or changing Python automatically.

## Participant stations
Use only the launchers in `Participant_Launchers`. The supplied Edge launchers contain the secure-origin configuration needed for browser camera/microphone access over the lab LAN.

## Troubleshooting
If setup fails, open `ARL_SETUP_LOG.txt`. Do not install ARL dependencies globally.

## Research distribution
The repository keeps the source code and `requirements.txt` visible for reproducibility. Generated `.venv`, experiment data, media, and local setup logs should not be committed.
