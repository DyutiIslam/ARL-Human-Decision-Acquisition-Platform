@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ARL - First-Time Environment Setup
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0_internal\setup_arl.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo ARL setup did not complete. See the message above.
pause
exit /b %RC%
