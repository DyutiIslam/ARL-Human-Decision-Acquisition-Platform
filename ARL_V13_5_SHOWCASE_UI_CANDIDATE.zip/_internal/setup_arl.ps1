﻿$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Venv = Join-Path $Root '.venv'
$Req = Join-Path $Root 'requirements.txt'
$Log = Join-Path $Root 'ARL_SETUP_LOG.txt'

Start-Transcript -Path $Log -Force | Out-Null
function Finish([int]$code) { try { Stop-Transcript | Out-Null } catch {}; exit $code }
function Fail([string]$msg) { Write-Host ''; Write-Host "[ERROR] $msg" -ForegroundColor Red; Write-Host "Setup log: $Log"; Finish 1 }
function Probe([string]$exe, [string[]]$args=@()) {
  try {
    $out = & $exe @args -c "import sys; print(str(sys.version_info.major)+'.'+str(sys.version_info.minor)+'|'+sys.executable)" 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $out) { return $null }
    $p = ($out | Select-Object -Last 1).Trim().Split('|',2)
    $v = [version]$p[0]
    if ($v.Major -eq 3 -and $v.Minor -ge 11 -and $v.Minor -le 13) {
      return @{Exe=$exe; Args=$args; Version=$p[0]; Path=$p[1]}
    }
  } catch {}
  return $null
}
function Find-CompatiblePython {
  $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
  if ($launcher) {
    foreach ($tag in @('-3.13','-3.12','-3.11')) {
      $c = Probe $launcher.Source @($tag)
      if ($c) { return $c }
    }
  }
  foreach ($name in @('python.exe','python3.exe')) {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -notlike '*WindowsApps*') {
      $c = Probe $cmd.Source
      if ($c) { return $c }
    }
  }
  $roots = @(
    (Join-Path $env:LOCALAPPDATA 'Programs\Python'),
    'C:\Python313','C:\Python312','C:\Python311'
  )
  foreach ($base in $roots) {
    if ($base -and (Test-Path $base)) {
      foreach ($candidate in @(Get-ChildItem -Path $base -Filter python.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)) {
        $c = Probe $candidate
        if ($c) { return $c }
      }
    }
  }
  return $null
}

Clear-Host
Write-Host '============================================================'
Write-Host ' ARL - FIRST-TIME ENVIRONMENT SETUP'
Write-Host '============================================================'
Write-Host 'ARL uses installed Python only to create its own isolated .venv.'
Write-Host 'Existing Python packages, PATH, VS Code and Anaconda are NOT modified.'
Write-Host 'Supported base Python: 3.11, 3.12 or 3.13.'
Write-Host '============================================================'
Write-Host ''

Write-Host '[1/4] Detecting compatible Python...'
$py = Find-CompatiblePython
if (-not $py) {
  Fail 'Python 3.11, 3.12 or 3.13 was not found. Install a supported Python version, then run 1_SETUP_ARL.bat again.'
}
Write-Host "      PASS - Python $($py.Version): $($py.Path)"

Write-Host '[2/4] Creating/verifying isolated ARL environment...'
$Vpy = Join-Path $Venv 'Scripts\python.exe'
if ((Test-Path $Venv) -and -not (Test-Path $Vpy)) {
  Write-Host '      Removing incomplete previous .venv...'
  Remove-Item -Recurse -Force $Venv
}
if (-not (Test-Path $Vpy)) {
  & $py.Exe @($py.Args) -m venv $Venv
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path $Vpy)) { Fail 'Could not create the ARL .venv.' }
}
Write-Host '      PASS - .venv ready'

Write-Host '[3/4] Installing/verifying ARL dependencies...'
& $Vpy -m pip install --disable-pip-version-check --upgrade pip
if ($LASTEXITCODE -ne 0) { Fail 'pip initialization failed.' }
& $Vpy -m pip install --disable-pip-version-check -r $Req
if ($LASTEXITCODE -ne 0) { Fail 'Dependency installation failed. Check internet access and ARL_SETUP_LOG.txt.' }
Write-Host '      PASS - dependencies ready'

Write-Host '[4/4] Running launch-readiness self-test...'
Push-Location $Root
try {
  & $Vpy -c "import fastapi,uvicorn,sqlmodel,pydantic,pylsl,pyxdf,pandas,numpy,tkinter; from app.main import app; print('      PASS - imports and ARL application')"
  if ($LASTEXITCODE -ne 0) { Fail 'ARL application self-test failed.' }
} finally { Pop-Location }

Write-Host ''
Write-Host '============================================================' -ForegroundColor Green
Write-Host ' ARL SETUP COMPLETE - READY TO LAUNCH' -ForegroundColor Green
Write-Host '============================================================' -ForegroundColor Green
Write-Host 'Existing Python/packages : NOT MODIFIED'
Write-Host 'Windows PATH             : NOT MODIFIED'
Write-Host 'ARL environment          : .venv'
Write-Host ''
Write-Host 'Next: double-click 2_START_ARL.bat'
Finish 0
