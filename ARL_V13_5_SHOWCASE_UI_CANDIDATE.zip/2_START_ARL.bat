@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ARL V13.5 - Moderator Server
set "PYEXE=%~dp0.venv\Scripts\python.exe"
set "PYTHONNOUSERSITE=1"
if not exist "%PYEXE%" (
  echo ================================================================
  echo ARL environment has not been set up on this computer.
  echo Please run 1_SETUP_ARL.bat once, then run 2_START_ARL.bat again.
  echo ================================================================
  pause
  exit /b 1
)
echo ================================================================
echo ARL V13.5 - GOLD Acquisition / Lab Ready
echo ================================================================
echo Moderator: http://127.0.0.1:8000/
echo Remote participants: use Participant_Launchers only.
echo Keep this window open during the session.
echo ================================================================
echo.
"%PYEXE%" -m uvicorn app.main:app --host 0.0.0.0 --port 8000
set "RC=%ERRORLEVEL%"
echo.
echo ARL server stopped. Exit code: %RC%
pause
exit /b %RC%
