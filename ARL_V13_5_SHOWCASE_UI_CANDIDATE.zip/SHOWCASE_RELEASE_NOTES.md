# ARL V13.5 — Showcase UI Candidate

This is a **UI candidate for lab testing**, not a validated research-release build.

## Changes
- Moderator: guided five-stage navigation, clearer headings/instructions, and existing emergency controls retained. Existing control elements and JavaScript handlers are moved intact into workflow stages; underlying `app/main.py`, acquisition, participant code and event handling are unchanged.
- Observer: one read-only live screen showing session/game/round/phase, speaking participant, participant connections, phase-specific response completion, current-round checkpoints, 35 station readiness checks, mapping identifiers, Pre-flight and marker/LabRecorder QC indicators.
- The Observer refreshes from existing server APIs. No new endpoints, database schema changes, or observer-side POST requests.
- 360-degree camera integration is not included.

## Important limitations
- Four physiological modalities per participant are 20 **logical modality checks**, not necessarily 20 distinct LSL outlets. The dashboard only labels a modality as sampled when a configured device mapping can be matched to a discovered LSL outlet and a sample was obtained. Non-matching streams remain **Not verified**, not green.
- Station/laptop names display only when available in the existing mapping; otherwise the dashboard explicitly says `Name unavailable`.
- Browser camera/microphone readiness relies on the existing `/api/media/status` report. It does not independently confirm saved video/audio files.
- LabRecorder QC is a human-confirmed checkbox in existing metadata; the application cannot independently prove XDF recording or file integrity from that checkbox.
- Moderator browser disconnection recovery has not been changed or validated.
- Session setup still contains original game control buttons, and original phase controls are not restricted by stage. Navigation is guidance, not an authorization or safety interlock.
- Observer scans of LSL may take several seconds. Status is refreshed approximately every 8 seconds, not at physiological sample rate.
- Current-round completion checkpoints are computed from response submissions; they are not a full historical multi-round audit.

## Lab acceptance test (required before showcase)
1. Extract into a **new clean folder**. Close all previous ARL and MMPPE servers. Use existing `1_SETUP_ARL.bat` and `2_START_ARL.bat` instructions; do not mix the candidate with old session folders.
2. Open `/` for Moderator and `/observer` for Observer on the same ARL server. Confirm all five Moderator stages work, that buttons remain functional, and that the Observer contains no buttons.
3. Configure P01–P05, map devices, save/lock setup, then confirm Observer displays mapping identifiers and correct missing/ready statuses.
4. Connect five participant browsers. Verify both windows show correct connect/disconnect transitions.
5. Run one complete test game (all speaking turns, voting, confidence, reasoning), verifying each participant's completion updates on both screens, and checkpoint completion is shown only after five submissions.
6. Verify EEG/ECG/EMG/GSR sample evidence against independent LSL inspection and LabRecorder stream selection. Inspect the actual XDF file.
7. Verify WEBM files and synchronization CSVs, events/behavior exports, and session integrity report. Do not infer successful recording from green UI indicators.
8. Close/reopen the Moderator browser mid-test. Check state and timer recovery without restarting the server. Separately test a full Moderator-host shutdown only with a recovery plan and backup data.

If any acceptance check fails, revert to the untouched original `ARL_V13_5_LAB_READY(3).zip` and report the failing step. Do not use this candidate for participant research collection until the five-station test passes.
