@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ARL XDF to CSV Converter
set "PYEXE=%~dp0.venv\Scripts\python.exe"
set "PYTHONNOUSERSITE=1"
if not exist "%PYEXE%" (
  echo ARL environment is not set up. Run 1_SETUP_ARL.bat first.
  pause
  exit /b 1
)
"%PYEXE%" -m app.xdf_to_csv_gui
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
